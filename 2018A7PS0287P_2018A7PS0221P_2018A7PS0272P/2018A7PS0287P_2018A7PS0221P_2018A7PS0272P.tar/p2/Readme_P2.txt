For executing clustershell_client.c
run the command
./crun <path_to_config_file>

For executing the clustershell_server.c
run the command
./srun <id_of_node> <ip_address_of_node> <path_to_config>