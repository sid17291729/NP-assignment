Students in group:
2018A7PS0287P - Siddharth Awasthi
2018A7PS0221P - Saransh Jindal
2018A7PS0272P - Arpit Kumar

The following files are included as solutions for each problem.

P1:
1. shell.c
2. makefile
3. design_doc_p1.pdf

P2:
1. clustershell_client.c
2. clustershell_server.c
3. makefile
4. readme_p2
5. config
6. p2_design_doc.pdf

P3:
1. msgq_client.c
2. msgq_server.c
3. q3_describe.pdf

